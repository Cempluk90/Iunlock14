#!/system/bin/sh
MODDIR=${0%/*}
su -c $MODDIR/iUnlocker-Game-Protector