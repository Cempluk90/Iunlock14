# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false
# Put true if you need system.prop
PROPFILE=true
# Put true if you need post-fs-data.sh
POSTFSDATA=true
# Put true if you need service.sh
LATESTARTSERVICE=true
# Only Works with iUnlocker if you have the Ram expansion key put this to true
#IUNLOCKER_RAMEXPANSION=true
. "$TMPDIR/function"


unzip -o "$ZIPFILE" 'system/*' -d $TMPDIR >&2
#unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
#unzip -o "$ZIPFILE" 'RamExpansion/*' -d $TMPDIR >&2
#unzip -o "$ZIPFILE" 'iSaddons/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'binkit/*' -d $TMPDIR >&2
ui_print " - installing ... "
  if [ "$abi" == "arm64-v8a" ]; then
IF64; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "x86" ]; then
IF32; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "armeabi-v7a" ]; then
  IF32; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "x86_64" ]; then
IF64; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "arm" ]; then
IF32; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "arm64" ]; then
IF64; SECURITY=true; echo -n " - {$abi}"
  elif [ "$abi" == "x64" ]; then
IF64; SECURITY=true; echo -n " - {$abi}"
else
iScreen " Abi not Verified abortion..."
exit 0
  fi


Remove_dir $TMPDIR/function
#chmod 777 $TMPDIR/iSaddons/*
#  chmod 777 $TMPDIR/iUnlocker
#  chmod 777 $TMPDIR/RamExpansion/*
  chmod 777 $TMPDIR/system/bin/iUnlocker-Game-Protector
#  chmod 777 $TMPDIR/system/lib*/*
